(function(){
	console.log(ait_php_var);
})();
