// JavaScript Document
alert( 'Hello');
alert( ait_php_var.external_link );
