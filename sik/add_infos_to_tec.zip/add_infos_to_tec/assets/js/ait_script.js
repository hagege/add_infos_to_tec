jQuery( document ).ready( function(){
    jQuery( 'input.color' ).wpColorPicker();
});